// One place to edit the business details shown in the footer and legal pages.
export const SITE = {
  name: "HikKing",
  tagline: "Trips across Bangladesh",
  email: "hello@hikking.com",
  phone: "+880 1XXX-XXXXXX",
  address: "Your office address, Dhaka, Bangladesh",
  hours: "Sat to Thu, 10:00 to 19:00",
  social: {
    facebook: "https://facebook.com/",
    instagram: "https://instagram.com/",
    youtube: "https://youtube.com/",
  },
};
